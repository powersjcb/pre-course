class Friend
  def greeting(name="")
    name=="" ? "Hello!" : "Hello, #{name}!"
  end
end

