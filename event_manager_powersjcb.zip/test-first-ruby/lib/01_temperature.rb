def ftoc(far)
  ((far-32.0)*5.0/9.0)
end

def ctof(cel)
  ((cel*9.0/5.0+32))
end
