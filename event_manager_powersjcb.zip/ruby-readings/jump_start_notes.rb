# puts "hello".methods.count
# puts :hello.methods

one = "this is going to be split into an array".split()
puts one.join(" ")
puts one.sort.join(" ")

