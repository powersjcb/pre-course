def digital_root(num)
  root = digital_root_step(num)

  while root > 9
    root = digital_root_step(root)
  end
  root
end


def digital_root_step(num)
  
  return num if num < 10
  
  sum = 0
  i = 10
  while i / 10 <= num
  sum += (num % i) / ( i / 10)
    i *= 10
  end
  sum


  # num.to_s.split("").map {|val| val.to_i}.inject(:+)
end



