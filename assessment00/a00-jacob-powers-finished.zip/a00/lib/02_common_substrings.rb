def common_substrings(str1, str2)

  if str1.length > str2.length
    str_short = str2
    str_long = str1
  else
    str_short = str1
    str_long = str2
  end


  longest = ""

  i = 0
  j = 1
  while i < str_short.length - 1
    j = i + 1
    while j < str_short.length 
        # puts str_short[i..j]
      if str_long.include?( str_short[i..j] ) && (j-i) > longest.length
        longest = str_short[i..j]
      end

      j += 1
    end 

    i += 1
  end
  longest
end


# puts common_substrings("zooglensnuck", "lenscrafters")