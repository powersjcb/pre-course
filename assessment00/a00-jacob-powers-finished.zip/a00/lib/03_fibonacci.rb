
def fib(num)
  return 0 if num == 1
  return 1 if  (num==2)

  fib(num-1) + fib(num-2)
end

def fibs(num)
  (1..num).to_a.map { |num| fib(num) }
end

# puts fibs(5)