def digital_root(num)
end
