def common_substrings(str1, str2)
end
