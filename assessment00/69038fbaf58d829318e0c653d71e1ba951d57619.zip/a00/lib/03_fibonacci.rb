def fibs(num)
end
