def digital_root(num)
  root = num

  #while root is still more than 2 digits
  while root > 10

    #handles sum
    i = 10
    divided =  1
    while divided > 10
      sum += root % i

      i *= 10
  end
  root
end
