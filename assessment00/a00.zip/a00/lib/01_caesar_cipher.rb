def caesar_cipher(str, shift)
  str.split.map do |word|
    word.chars.map {|char| ((char.ord - 97 + shift) % 26 + 97).chr }.join
  end .join(" ")
end


# puts caesar_cipher('z', 1)